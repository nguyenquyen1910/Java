package thoigianlamviec;


public class NhanVien implements Comparable<NhanVien> {
    private String id;
    private String name;
    private String timeStart;
    private String timeEnd;
    private String status;
    private long timeOfWork;

    public NhanVien(String id, String name, String timeStart, String timeEnd) {
        this.id = id;
        this.name = name;
        this.timeStart = timeStart;
        this.timeEnd = timeEnd;
        this.timeOfWork = solveTimeOfWork();
        this.status = solveStatus();
    }

    private long solveTimeOfWork() {
        long timeStartMinutes = Long.parseLong(timeStart.substring(0,2)) * 60 + Long.parseLong(timeStart.substring(3));
        long timeEndMinutes = Long.parseLong(timeEnd.substring(0,2)) * 60 + Long.parseLong(timeEnd.substring(3));
        return timeEndMinutes - timeStartMinutes - 60;
    }

    private String solveStatus(){
        long timeStartMinutes = Long.parseLong(timeStart.substring(0,2)) * 60 + Long.parseLong(timeStart.substring(3));
        long timeEndMinutes = Long.parseLong(timeEnd.substring(0,2)) * 60 + Long.parseLong(timeEnd.substring(3));
        if(timeEndMinutes - timeStartMinutes - 60 > 8 * 60){
            return "DU";
        }
        return "THIEU";
    }

    @Override
    public String toString() {
        return id+" "+name+" "+(timeOfWork/60)+" gio "+(timeOfWork%60)+" phut "+status;
    }

    @Override
    public int compareTo(NhanVien o) {
        if(this.timeOfWork != o.timeOfWork){
            return (int)(o.timeOfWork-this.timeOfWork);
        }
        return this.id.compareTo(o.id);
    }
}
