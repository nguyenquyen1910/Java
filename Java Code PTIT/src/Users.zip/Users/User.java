package Users;

public class User {
    private String userCheck;

    public User(String userCheck) {
        this.userCheck = userCheck;
    }
    public String getUserCheck() {
        return userCheck;
    }
}
