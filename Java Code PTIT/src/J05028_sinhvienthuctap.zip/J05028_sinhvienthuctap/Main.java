package J05028_sinhvienthuctap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n=Integer.parseInt(sc.nextLine());
        List<TapDoan> list=new ArrayList<>();
        for(int i=0;i<n;i++){
            list.add(new TapDoan(sc.nextLine(),sc.nextLine(),Integer.parseInt(sc.nextLine())));
        }
        Collections.sort(list);
        for(TapDoan x : list){
            System.out.println(x.toString());
        }
    }
}
