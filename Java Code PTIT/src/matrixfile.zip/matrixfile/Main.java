package matrixfile;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);
    public static void testCase(){
        int n=sc.nextInt();
        int m=sc.nextInt();
        int idx=sc.nextInt();
        idx-=1;
        List<Integer> list=new ArrayList<>();
        for(int i=0;i<n*m;i++){
            list.add(sc.nextInt());
        }
        Matrix matrix = new Matrix(list,n,m,idx);
        System.out.println(matrix);
    }
    public static void main(String[] args) {
        int t=sc.nextInt();
        while(t-->0){
            testCase();
        }
    }
}
