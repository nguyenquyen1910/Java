package J07047_quanlikhachsan;

public class KhachSan {
    private String info;
    private String id,type;
    private double price;
    private double fee;

    public KhachSan(String info) {
        this.info = info;
        String[] tmp = info.split("\\s+");
        this.id = tmp[0];
        this.type = tmp[1];
        this.price = Double.parseDouble(tmp[2]);
        this.fee = Double.parseDouble(tmp[3]);
    }

    public String getId(){
        return id;
    }

    public String getType(){
        return type;
    }

    public double getPrice(){
        return price;
    }

    public double getFee() {
        return fee;
    }
}
