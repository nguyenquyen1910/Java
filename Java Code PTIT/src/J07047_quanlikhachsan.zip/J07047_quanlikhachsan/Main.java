package J07047_quanlikhachsan;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Main {
    public static void main(String[] args) throws ParseException, FileNotFoundException {
        Scanner sc = new Scanner(new File("DATA.in"));
        int n = Integer.parseInt(sc.nextLine());
        List<KhachSan> listKS = new ArrayList<>();
        for(int i=0;i<n;i++){
            listKS.add(new KhachSan(sc.nextLine()));
        }
        int m=Integer.parseInt(sc.nextLine());
        List<KhachHang> listKH = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        for(int i=0;i<m;i++){
            listKH.add(new KhachHang(i,sc.nextLine(),sc.nextLine(),sdf.parse(sc.nextLine()),sdf.parse(sc.nextLine())));
        }

        for(KhachHang khachHang : listKH){
            for(KhachSan khachSan : listKS){
                String tmp=String.valueOf(khachHang.getIdRoom().charAt(2));
                if(tmp.equals(khachSan.getId())){
                    khachHang.setKhachSan(khachSan);
                }
            }
        }
        Collections.sort(listKH);
        for(KhachHang khachHang : listKH){
            System.out.println(khachHang);
        }

    }
}
