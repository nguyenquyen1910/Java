package J07047_quanlikhachsan;

import java.util.Date;

public class KhachHang implements Comparable<KhachHang> {
    private String cusId;
    private String cusName;
    private String idRoom;
    private Date checkIn;
    private Date checkOut;
    private Long days;
    private double discount;
    private double price;
    private KhachSan khachSan;

    public KhachHang(int i, String cusName, String idRoom, Date checkIn, Date checkOut) {
        this.cusId = "KH"+String.format("%02d",i+1);
        this.cusName = cusName;
        this.idRoom = idRoom;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.days = solveDays();
    }

    public String getIdRoom() {
        return idRoom;
    }

    public void setKhachSan(KhachSan khachSan) {
        this.khachSan = khachSan;
        this.price = solvePrice();
        this.discount = sovleDiscount();
    }

    public Long solveDays(){
        long tmp = (this.checkOut.getTime()-this.checkIn.getTime()) / (1000L * 60 *60 * 24);
        return tmp == 0 ? 1 : tmp;
    }

    public double solvePrice(){
        return (khachSan.getPrice() + khachSan.getPrice() * khachSan.getFee())*days;
    }

    public double sovleDiscount(){
        double res=this.price;
        if(days<10){
            res=0;
        }
        else if(10<=this.days && this.days<20){
            res*=0.02;
        }
        else if(20<=this.days && this.days<30){
            res*=0.04;
        }
        else if(this.days>=30){
            res*=0.06;
        }
        return res;
    }

    public KhachSan getKhachSan() {
        return khachSan;
    }

    @Override
    public String toString() {
        return cusId+" "+cusName+" "+idRoom+" "+days+" "+String.format("%.2f",(price-discount));
    }

    @Override
    public int compareTo(KhachHang o) {
        return Long.compare(o.days, this.days);
    }
}
