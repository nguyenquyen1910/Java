package muahang;

public class Product {
    private String prodId;
    private String prodName;
    private int prodPrice;
    private int prodWantity;

    public Product(String prodId, String prodName, int prodPrice, int prodWantity) {
        this.prodId = prodId;
        this.prodName = prodName;
        this.prodPrice = prodPrice;
        this.prodWantity = prodWantity;
    }

    public String getProdId() {
        return prodId;
    }

    public int getProdPrice() {
        return prodPrice;
    }

    public int getProdWantity() {
        return prodWantity;
    }
}
