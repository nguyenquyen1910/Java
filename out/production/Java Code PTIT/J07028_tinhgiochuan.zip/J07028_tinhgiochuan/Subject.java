package J07028_tinhgiochuan;

public class Subject {
    private String subId;
    private String subName;

    public Subject(String subId, String subName) {
        this.subId = subId;
        this.subName = subName;
    }
}
