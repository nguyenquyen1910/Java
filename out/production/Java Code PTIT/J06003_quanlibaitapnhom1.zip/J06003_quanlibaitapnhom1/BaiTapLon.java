package J06003_quanlibaitapnhom1;

public class BaiTapLon {
    private int id;
    private String name;

    public BaiTapLon(int i, String name) {
        this.id = i+1;
        this.name = name;
    }
    public String getName() {
        return name;
    }
}
