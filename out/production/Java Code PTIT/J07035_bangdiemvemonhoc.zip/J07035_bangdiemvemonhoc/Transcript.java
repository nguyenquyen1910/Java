package J07035_bangdiemvemonhoc;

public class Transcript implements Comparable<Transcript> {
    private String stuId;
    private String subId;
    private double score;
    private String point;
    private Subject subject;
    private Student student;

    public Transcript(String stuId, String subId, String point) {
        this.stuId = stuId;
        this.subId = subId;
        this.point = point;
        this.score = Double.parseDouble(point);
    }

    public String getSubId() {
        return subId;
    }

    public String getStuId() {
        return stuId;
    }

    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    @Override
    public int compareTo(Transcript o) {
        if(this.score != o.score){
            return Double.compare(o.score, this.score);
        }
        return this.stuId.compareTo(o.stuId);
    }

    @Override
    public String toString() {
        return student.getStuId()+" "+student.getStuName()+" "+student.getStuClass()+" "+point;
    }
}
