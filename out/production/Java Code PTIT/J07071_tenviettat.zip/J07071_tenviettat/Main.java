package J07071_tenviettat;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static boolean compare(String s,String p) {
        if(s.length() != p.length())
            return false;
        for(int i = 0; i < s.length(); i++) {
            if(s.charAt(i) == '*')
                continue;
            if(s.charAt(i) != p.charAt(i))
                return false;
        }
        return true;
    }
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("DANHSACH.in"));
        int n = Integer.parseInt(sc.nextLine());
        List<HoTen> list = new ArrayList<>();
        for(int i=0;i<n;i++){
            list.add(new HoTen(sc.nextLine()));
        }
        Collections.sort(list);
        int q=Integer.parseInt(sc.nextLine());
        while(q-->0){
            String tmpName=sc.nextLine();
            for(HoTen it : list){
                if(compare(tmpName,it.getShortname())){
                    System.out.println(it);
                }
            }
        }
    }
}
