package J07071_tenviettat;

public class HoTen implements Comparable<HoTen> {
    private String fullname;
    private String lastname;
    private String firstname;
    private String shortname;

    public HoTen(String fullname) {
        this.fullname = fullname;
        this.lastname = solveLastname();
        this.firstname = solveFirstname();
        this.shortname = solveShortname();
    }

    public String solveLastname(){
        String[] tmp=fullname.split("\\s+");
        return tmp[tmp.length-1];
    }

    public String solveFirstname(){
        String[] tmp=fullname.split("\\s+");
        String res="";
        for(int i=0;i<tmp.length-1;i++){
            res+=tmp[i]+" ";
        }
        return res.trim();
    }

    public String solveShortname(){
        String[] tmp=fullname.split("\\s+");
        String res="";
        for(int i=0;i<tmp.length-1;i++){
            res+=tmp[i].charAt(0)+".";
        }
        res+=tmp[tmp.length-1].charAt(0);
        return res;
    }

    public String getShortname() {
        return shortname;
    }

    @Override
    public int compareTo(HoTen o) {
        if(!this.lastname.equals(o.lastname)){
            return this.lastname.compareTo(o.lastname);
        }
        return this.firstname.compareTo(o.firstname);
    }

    @Override
    public String toString() {
        return fullname;
    }
}
