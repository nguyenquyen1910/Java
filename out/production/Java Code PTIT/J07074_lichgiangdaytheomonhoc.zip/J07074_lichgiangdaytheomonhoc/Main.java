package J07074_lichgiangdaytheomonhoc;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("MONHOC.in"));
        int n = Integer.parseInt(sc.nextLine());
        List<Subject> subjects = new ArrayList<>();
        for(int i=0;i<n;i++){
            subjects.add(new Subject(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine())));
        }
        Scanner sc1 = new Scanner(new File("LICHGD.in"));
        int m = Integer.parseInt(sc1.nextLine());
        List<Schedule> schedules = new ArrayList<>();
        for(int i=0;i<m;i++){
            schedules.add(new Schedule(i, sc1.nextLine(), sc1.nextLine(), Integer.parseInt(sc1.nextLine()), sc1.nextLine(), sc1.nextLine()));
        }

        for(Schedule schedule : schedules){
            for(Subject subject : subjects){
                if(schedule.getSubId().equals(subject.getSubId())){
                    schedule.setSubject(subject);
                    break;
                }
            }
        }

        Collections.sort(schedules);
        String query = sc1.nextLine();
        String subName = "";
        List<Schedule> res = new ArrayList<>();
        for(Schedule schedule : schedules){
            if(schedule.getSubId().equals(query)){
                subName = schedule.getSubject().getSubName();
                res.add(schedule);
            }
        }
        System.out.println("LICH GIANG DAY MON "+subName+":");
        res.forEach(System.out::println);
    }
}
