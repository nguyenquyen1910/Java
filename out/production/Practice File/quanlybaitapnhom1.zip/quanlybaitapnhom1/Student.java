package quanlybaitapnhom1;

public class Student {
    private String stuId;
    private String stuName;
    private String stuPhone;
    private int exId;
    public Student(String stuId, String stuName, String stuPhone, int exId) {
        this.stuId = stuId;
        this.stuName = stuName;
        this.stuPhone = stuPhone;
        this.exId = exId;
    }

    public String getStuId() {
        return stuId;
    }

    public int getExId() {
        return exId;
    }

    @Override
    public String toString() {
        return stuId+" "+stuName+" "+stuPhone;
    }
}
