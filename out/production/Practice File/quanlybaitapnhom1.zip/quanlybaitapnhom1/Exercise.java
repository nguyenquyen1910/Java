package quanlybaitapnhom1;

import java.util.ArrayList;
import java.util.List;

public class Exercise {
    private int exid;
    private String exName;
    private List<Student> students;
    public Exercise(int i, String exName) {
        this.exid = i+1;
        this.exName = exName;
        this.students = new ArrayList<Student>();
    }

    public int getExid() {
        return exid;
    }

    public String getExName() {
        return exName;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }
}
