package bangtinhgiochuan;

public class Subject {
    private String subId;
    private String subName;
    public Subject(String subId, String subName) {
        this.subId = subId;
        this.subName = subName;
    }

    public String getSubId() {
        return subId;
    }

    public String getSubName() {
        return subName;
    }
}
